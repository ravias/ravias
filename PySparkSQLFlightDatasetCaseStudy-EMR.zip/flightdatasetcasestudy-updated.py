# import pyspark
# from pyspark.sql import SparkSession

# spark = SparkSession.builder.appName("Flight Data Case Study").getOrCreate()

airportDF = spark.read.load("s3://fra-bkt-0507/inputdata/airportdata.csv", format="csv",inferSchema="true",header="true")

flightDF = spark.read.load("s3://fra-bkt-0507/inputdata/flightdata.csv", format="csv",inferSchema="true",header="true")

# Check the count of records of the dataframe.
airportDF.count()

flightDF.count()

airportDF.printSchema()

# Check the schema of the dataframe. Specifically look for airTime and arrivalDelay columns of flight data
flightDF.printSchema()

airportDF.show(5,False)

flightDF.show(5,False)

# Check the data description i.e. stats of all columns
airportDF.describe().show()

flightDF.describe().show()

# For a specific column the stats can be checked as below
flightDF.describe("distance").show()

from pyspark.sql.functions import *

# 1. Check the schema of the data frame after having flight data. The columns airtime and arrivalDelay would be inferred as string. This is because some of the rows have “NA” in these columns. Remove these rows using filter function and cast these columns to integer.

flightDF2=flightDF.where(col("airTime") != "NA").withColumn("airTime",col("airTime").cast("Integer")).withColumn("arrivalDelay",col("arrivalDelay").cast("Integer"))

flightDF2.count()

# Now check and compare the data type of airTime and arrivalDelay columns
flightDF2.printSchema()

# 2. As some of the reports require month-wise breakup of flight data, add a column with the number of the month and another column with the name of the month extracted from the date column.

# Add a column start_to_date by converting startDate column from string to date

flightDF3=flightDF2.withColumn("start_to_date",(to_date(col("startDate"), "M/d/yyyy")))

flightDF3.printSchema()

flightDF3.show()

# Example date functions
flightDF3.select( "start_to_date",
                 year(col("start_to_date")).alias("year"),
                 month(col("start_to_date")).alias("month"),
                 dayofweek(col("start_to_date")).alias("dayofweek"), 
                 date_format("start_to_date", "EEEE").alias("dayofweek_full"),
                 date_format("start_to_date", "E").alias("dayofweek_short"),
                 dayofmonth(col("start_to_date")).alias("dayofmonth"), 
                 dayofyear(col("start_to_date")).alias("dayofyear"), 
                 next_day(col("start_to_date"),"Sunday").alias("next_day"), 
                 weekofyear(col("start_to_date")).alias("weekofyear") 
   ).show()

flightDF4 = flightDF3.withColumn("month",(month(col("start_to_date"))))

flightDF4.printSchema()

flightDF4.show()

# 3. In the flight data, add a new column cancellationReason and populate it as per the following conditions.
#    1 - Carrier
#    2 - Weather
#    3 - NAS
#    4 - Security

# Using when & otherwise function
flightDF5=flightDF4.withColumn("cancelReason", when( col("cancellationCode")==1,lit("carrier")).
                               when( col("cancellationCode")==2,lit("weather")).
                               when( col("cancellationCode")==3,lit("NAS")).
                               when( col("cancellationCode")==4,lit("security")).
                               otherwise(col("cancellationCode")) )

flightDF5.printSchema()

flightDF5.show()

# Using a Map and .na.replace function contents of the existing column can be replaced with new values
# This will not add a new column. It uses the existing column and replaces the values
ccdict={1:"carrier", 2:"weather", 3:"NAS", 4:"security"}
flightDF5A=flightDF4.withColumn("cancellationCode",col("cancellationCode").cast("String")).na.replace(['1','2','3','4'], ['carrier','weather','NAS','security'],"cancellationCode")

flightDF5A.printSchema()

flightDF5A.show()

# 4. As some of the reports require airport names to be provided, add the columns of the airport data by join.
# Join is done with airport data on airport code and origin code once and the on airport code and destination code

flightDF6 = flightDF5.join(airportDF,flightDF5.origin == airportDF.code, "inner").withColumnRenamed("code","originCode").withColumnRenamed("name","originName").withColumnRenamed("areaCode","originAreaCode")

# empDF.join(deptDF,empDF.emp_dept_id ==  deptDF.dept_id,"inner")

flightDF6.printSchema()

flightDF6.show(5,False)

flightDF7 = flightDF6.join(airportDF,flightDF6.destination == airportDF.code, "inner").withColumnRenamed("code","destCode").withColumnRenamed("name","destName").withColumnRenamed("areaCode","destAreaCode")

flightDF7.printSchema()

flightDF7.show(5,False)

# This completes the pre-processing of the data.
# We should be able to generate the reports from this dataframe.

# 5. Give the breakup of number of cancellations based on origin airport. Which origin airport had maximum cancellations? Airport names should be mentioned in the list in addition to the airport code.
flightDF7.filter(col("cancelled")==1).count() # to verify total count

flightDF7.filter(col("cancelled")==1).groupBy("originName").agg(count("cancelled").alias("cancel_count")).orderBy(col("cancel_count").desc()).show(5,False)

fDF8=flightDF7.filter(col("cancelled")==1).groupBy("originName").agg(count("cancelled").alias("cancel_count")).orderBy(col("cancel_count").desc())
# Save the result into a Hive table or a CSV file as required

fDF8.show()

# 6. Give reason-wise breakup of cancellations. What is the reason recorded for maximum number of cancellations?
flightDF7.filter(col("cancelled")==1).groupBy("cancelReason").agg(count("cancelled").alias("cancel_count")).orderBy(col("cancel_count").desc()).show(5,False)

fDF9=flightDF7.filter(col("cancelled")==1).groupBy("cancelReason").agg(count("cancelled").alias("cancel_count")).orderBy(col("cancel_count").desc())
# Save the result into a Hive table or a CSV file as required

fDF9.show()

#7. Give month-wise breakup of cancellations from the available data. Which month has maximum number of cancellations?
flightDF7.filter(col("cancelled")==1).groupBy("month").agg(count("cancelled").alias("cancel_count")).orderBy(col("cancel_count").desc()).show()

fDF10=flightDF7.filter(col("cancelled")==1).groupBy("month").agg(count("cancelled").alias("cancel_count")).orderBy(col("cancel_count").desc())
fDF10.show()

# 8. Give the breakup of number of diversions based on destination airport. Which destination airport caused maximum diversions? Airport names should be mentioned in the list in addition to the airport code.
flightDF7.filter(col("diverted")=="Yes").count() # to verify total count

flightDF7.filter(col("diverted")=="Yes").groupBy("destName").agg(count("diverted").alias("divert_count")).orderBy(col("divert_count").desc()).show(5,False)

fDF11= flightDF7.filter(col("diverted")=="Yes").groupBy("destName").agg(count("diverted").alias("divert_count")).orderBy(col("divert_count").desc())
# Save the result into a Hive table or a CSV file as required
fDF11.show(5,False)

# 9. Give month-wise breakup of diversions from the available data. Which month has maximum number of diversions?
flightDF7.filter(col("diverted")=="Yes").groupBy("month").agg(count("diverted").alias("divert_count")).orderBy(col("divert_count").desc()).show(truncate=False)

fDF12=flightDF7.filter(col("diverted")=="Yes").groupBy("month").agg(count("diverted").alias("divert_count")).orderBy(col("divert_count").desc())
# Save the result into a Hive table or a CSV file as required
fDF12.show(truncate=False)

# 10. Provide a listing giving the number of flights that arrived ahead of the scheduled time, flights that arrived on time and the flights that arrived late.
flightDF7.filter(col("arrivalDelay")<0).count()
flightDF7.filter(col("arrivalDelay")<0).agg(count("arrivedDelay").as("arrivedAheadCount")).show()

flightDF7.filter(col("arrivalDelay")==0).count()
flightDF7.filter(col("arrivalDelay")==0).agg(count("arrivalDelay").as("arrivedOnTime")).show()

flightDF7.filter(col("arrivalDelay")>0).count()
flightDF7.filter(col("arrivalDelay")>0).agg(count("arrivalDelay").as("arrivedLate")).show()

fDF13=flightDF7.
withColumn("arrivedAhead", when(col("arrivalDelay")<0,1 )).
withColumn("arrivedOnTime", when(col("arrivalDelay")===0,1 )).
withColumn("arrivedLate", when(col("arrivalDelay")>0,1 ))
fDF13.show()
fDF13.printSchema()

fDF13.agg(
    sum("arrivedAhead").as("arrivedAheadCount"), 
    sum("arrivedOnTime").as("arrivedOnTimeCount"), 
    sum("arrivedLate").as("arrivedLateCount") 
).show()

fDF13A= fDF13.agg(
    sum("arrivedAhead").as("arrivedAheadCount"), 
    sum("arrivedOnTime").as("arrivedOnTimeCount"), 
    sum("arrivedLate").as("arrivedLateCount") 
)
fDF13A.show()
fDF13A.printSchema()

flightDF7.
withColumn("arrivedAhead", when(col("arrivalDelay")<0,1 )).
withColumn("arrivedOnTime", when(col("arrivalDelay")===0,1 )).
withColumn("arrivedLate", when(col("arrivalDelay")>0,1 )).
agg(
    sum("arrivedAhead").as("arrivedAheadCount"), 
    sum("arrivedOnTime").as("arrivedOnTimeCount"), 
    sum("arrivedLate").as("arrivedLateCount") 
).show()

fDF13B=flightDF7.
withColumn("arrivedAhead", when(col("arrivalDelay")<0,1 )).
withColumn("arrivedOnTime", when(col("arrivalDelay")===0,1 )).
withColumn("arrivedLate", when(col("arrivalDelay")>0,1 )).
agg(
    sum("arrivedAhead").as("arrivedAheadCount"), 
    sum("arrivedOnTime").as("arrivedOnTimeCount"), 
    sum("arrivedLate").as("arrivedLateCount") 
)
fDF13B.show(5,false)
fDF13B.printSchema()


flightDF7.filter(col("arrivalDelay")<0).count()

flightDF7.filter(col("arrivalDelay")==0).count()

flightDF7.filter(col("arrivalDelay")>0).count()

fDF13=flightDF7.withColumn("arrivedAhead", when(col("arrivalDelay")<0,1 )).withColumn("arrivedOnTime", when(col("arrivalDelay")==0,1 )).withColumn("arrivedLate", when(col("arrivalDelay")>0,1 ))
fDF13.show()
fDF13.printSchema()

fDF13A= fDF13.agg(    sum("arrivedAhead").alias("arrivedAheadCount"),     sum("arrivedOnTime").alias("arrivedOnTimeCount"),     sum("arrivedLate").alias("arrivedLateCount") )
fDF13A.show()
fDF13A.printSchema()

fDF13B=flightDF7. withColumn("arrivedAhead", when(col("arrivalDelay")<0,1 )). withColumn("arrivedOnTime", when(col("arrivalDelay")==0,1 )). withColumn("arrivedLate", when(col("arrivalDelay")>0,1 )). agg(    sum("arrivedAhead").alias("arrivedAheadCount"),     sum("arrivedOnTime").alias("arrivedOnTimeCount"),     sum("arrivedLate").alias("arrivedLateCount") )
fDF13B.show(5,False)
fDF13B.printSchema()

flightDF7. withColumn("arrivedAhead", when(col("arrivalDelay")<0,1 )). withColumn("arrivedOnTime", when(col("arrivalDelay")==0,1 )). withColumn("arrivedLate", when(col("arrivalDelay")>0,1 )). agg(     sum("arrivedAhead").alias("arrivedAheadCount"),     sum("arrivedOnTime").alias("arrivedOnTimeCount"),     sum("arrivedLate").alias("arrivedLateCount") ).show()

# 11. Generate the above list for flights that have been diverted.
fDF14=flightDF7.filter(col("diverted")=="Yes"). withColumn("arrivedAhead", when(col("arrivalDelay")<0,1 )). withColumn("arrivedOnTime", when(col("arrivalDelay")==0,1 )). withColumn("arrivedLate", when(col("arrivalDelay")>0,1 )). agg(     sum("arrivedAhead").alias("arrivedAheadCount"),     sum("arrivedOnTime").alias("arrivedOnTimeCount"),     sum("arrivedLate").alias("arrivedLateCount") )
fDF14.show(5,False)
fDF14.printSchema()

# 12. Generate the above list for flights that have not been diverted.
fDF15=flightDF7.filter(col("diverted")=="No"). withColumn("arrivedAhead", when(col("arrivalDelay")<0,1 )). withColumn("arrivedOnTime", when(col("arrivalDelay")==0,1 )). withColumn("arrivedLate", when(col("arrivalDelay")>0,1 )). agg(     sum("arrivedAhead").alias("arrivedAheadCount"),     sum("arrivedOnTime").alias("arrivedOnTimeCount"),     sum("arrivedLate").alias("arrivedLateCount") )
fDF15.show(5,False)
fDF15.printSchema()

