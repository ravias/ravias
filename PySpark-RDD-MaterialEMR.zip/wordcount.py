
lines = sc.textFile("war_and_peace.txt",4)
type(lines)

lines.count()

lines.first()

lines.take(5)

lines.getNumPartitions()

def count_in_a_partition(iterator):
    yield sum(1 for _ in iterator)

lines.mapPartitions(count_in_a_partition).collect()

nonNullLines = lines.filter(lambda line: len(line)>0)

nonNullLines.count()

nonNullLines.first()

nonNullLines.take(5)

nonNullLines.mapPartitions(count_in_a_partition).collect()

words = nonNullLines.flatMap(lambda line: line.split())

words.count()

words.first()

words.take(5)

upperWords = words.map(lambda word: word.upper())

upperWords.count()

upperWords.first()

upperWords.take(5)

pairedOnes = upperWords.map(lambda uw: (uw, 1))

pairedOnes.count()

pairedOnes.first()

pairedOnes.take(5)

wordCounts = pairedOnes.reduceByKey(lambda p, n: p + n)

wordCounts.count()

wordCounts.first()

wordCounts.take(5)

for word in wordCounts.take(5):
    print "*****", word

# We can also create an RDD from an existing collection of data elements using parallelize method of SparkContext.

data = [1, 2, 3, 4, 5]

type(data)

distData = sc.parallelize(data,2)

type(distData)

distData.getNumPartitions()

quit()

