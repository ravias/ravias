
lines = sc.textFile("war_and_peace.txt",4)
type(lines)

lines.count()

nonNullLines = lines.filter(lambda line: len(line)>0)
words = nonNullLines.flatMap(lambda line: line.split())

words.count()

quit()
