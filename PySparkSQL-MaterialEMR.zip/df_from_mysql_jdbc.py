# This pyspark application connects to a mysql database and loads a table into a dataframe and shows the top 20 rows
# It can be launched or run with the following command

# spark-submit --master yarn --jars /opt/cloudera/parcels/CDH-6.2.1-1.cdh6.2.1.p0.1425774/lib/sqoop/lib/mysql-connector-java-5.1.7/mysql-connector-java-5.1.7-bin.jar df_from_mysql_jdbc.py

import pyspark
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("PySpark MySQL JDBC example").getOrCreate()

jdbcDF = spark.read \
    .format("jdbc") \
    .option("url", "jdbc:mysql://10.1.1.204/bigmindhadoop7613") \
    .option("driver", "com.mysql.jdbc.Driver") \
    .option("dbtable", "books") \
    .option("user", "bigmindhadoop7613") \
    .option("password", "bigmind123") \
    .load()

jdbcDF.printSchema()
jdbcDF.show()

