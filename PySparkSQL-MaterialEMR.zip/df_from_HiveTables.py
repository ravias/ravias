spark.sql("create database ravias")

-- From Hive shell create tables as given in the accompnying HQL script file
-- Run the following PySpark code

spark.sql("use ravias")

spark.sql("SELECT * FROM customers").show(5)

spark.sql("SELECT * FROM products").show(5)

cStateCount50 = spark.sql("SELECT customer_state, count(*) as state_count FROM customers GROUP BY customer_state HAVING state_count>=50")

# Output of a Hive query will be a DataFrame 

type(cStateCount50)

cStateCount50.printSchema()

cStateCount50.show()

prd200 = spark.sql("SELECT category_id, product_category, count(*) as prdcount FROM products WHERE product_price>200 GROUP BY category_id, product_category ORDER BY product_category")

type(prd200)

prd200.show()

prd200.printSchema()

# Write these dataframes into Hive tables of the same database

cStateCount50.coalesce(1).write.saveAsTable("ravias.cStateCount50")

prd200.coalesce(1).write.saveAsTable("ravias.prd200")
