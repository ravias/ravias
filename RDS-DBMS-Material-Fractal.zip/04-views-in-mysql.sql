-- Creating a simple view
-------------------------
CREATE VIEW salePerOrder AS
    SELECT 
        orderNumber, 
        SUM(quantityOrdered * priceEach) total
    FROM
        orderdetails
    GROUP by orderNumber
    ORDER BY total DESC;
-----
SHOW TABLES;
-----
SHOW FULL TABLES;
-----
SELECT * FROM salePerOrder;
-----

-- Creating a view based on another view
----------------------------------------
CREATE VIEW bigSalesOrder AS
    SELECT 
        orderNumber, 
        ROUND(total,2) as total
    FROM
        salePerOrder
    WHERE
        total > 60000;
-----
SELECT 
    orderNumber, 
    total
FROM
    bigSalesOrder;
-----

-- Creating a view with join
----------------------------
CREATE OR REPLACE VIEW customerOrders AS
SELECT 
    orderNumber,
    customerName,
    SUM(quantityOrdered * priceEach) total
FROM
    orderDetails
INNER JOIN orders o USING (orderNumber)
INNER JOIN customers USING (customerNumber)
GROUP BY orderNumber;
-----
SELECT * FROM customerOrders 
ORDER BY total DESC;
-----

-- Creating a view with a subquery
----------------------------------
CREATE VIEW aboveAvgProducts AS
    SELECT 
        productCode, 
        productName, 
        buyPrice
    FROM
        products
    WHERE
        buyPrice > (
            SELECT 
                AVG(buyPrice)
            FROM
                products)
    ORDER BY buyPrice DESC;
-----
SELECT * FROM aboveAvgProducts;
-----

-- Creating a view with explicit columns specified
--------------------------------------------------
CREATE VIEW customerOrderStats (
   customerName , 
   orderCount
) 
AS
    SELECT 
        customerName, 
        COUNT(orderNumber)
    FROM
        customers
            INNER JOIN
        orders USING (customerNumber)
    GROUP BY customerName;
-----
SELECT 
    customerName,
    orderCount
FROM
    customerOrderStats
ORDER BY 
	orderCount, 
    customerName;
-----

-- SHOW FULL TABLES statement
-----------------------------
SHOW FULL TABLES  WHERE table_type = 'VIEW';

SHOW FULL TABLES [{FROM | IN } database_name] 
WHERE table_type = 'VIEW';

SELECT * FROM information_schema.tables;

SELECT table_name view_name FROM information_schema.tables 
WHERE table_type   = 'VIEW' AND
table_schema = 'classicmodels';

-- Index
--------
SHOW INDEX from customers;

SHOW INDEX from employees;
