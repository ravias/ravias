use <Your Database Name here>;
show tables;

describe customers;
select customernumber, customername, state, city from customers where state is not null;
select customernumber, customername, state, city from customers where state is null;
select customernumber, customername, state, city from customers where state='CA';
select customernumber, customername, city from customers where state='CA';

show tables;
describe products;

describe orderdetails;
describe orders;

select productcode, productname, buyprice from products where productline='Classic Cars';
select productline, count(*) as productcount from products group by productline;
select productline, count(*) as productcount, avg(buyprice) as avgbuyprice, avg(msrp) as avgmsrp from products group by productline;

select productline, count(*) as productcount, max(buyprice) as maxbuyprice, max(msrp) as maxmsrp, min(buyprice) as minbuyprice, min(msrp) as minmsrp  from products group by productline;

select productline, count(*) as productcount, avg(buyprice) as avgbuyprice, avg(msrp) as avgmsrp from products group by productline having avgbuyprice>=50;
select productline, count(*) as productcount, avg(buyprice) as avgbuyprice, avg(msrp) as avgmsrp from products group by productline order by avgmsrp;
select productline, count(*) as productcount, avg(buyprice) as avgbuyprice, avg(msrp) as avgmsrp from products group by productline order by avgmsrp desc;

select count(*) from customers;
select count(state) from customers; -- This is equivalent to the query below.
select count(state) from customers where state is not null;
select count(state) from customers where state is null; -- Count(var1) counts non NULL values only. Therefore missing values cannot be counted through count function.
select count(*) from customers where state is not null;
select count(*) from customers where state is null;  -- This query can be used to get count of records with missing values for the column state.
select distinct(state) from customers;
select state, count(*) from customers group by state;

SELECT COUNT(*) total,
COUNT(state) nonmissing,
COUNT(*) - COUNT(state) missing,
((COUNT(*) - COUNT(state)) * 100) / COUNT(*) 'perc_missing' from customers;

SELECT COUNT(*) total,
COUNT(state) nonmissing,
COUNT(*) - COUNT(state) missing,
((COUNT(*) - COUNT(state)) * 100) / COUNT(*) percMissing from customers;

SELECT COUNT(*),
COUNT(state),
COUNT(*) - COUNT(state),
((COUNT(*) - COUNT(state)) * 100) / COUNT(*) from customers;

SELECT COUNT(*)
FROM INFORMATION_SCHEMA.COLUMNS
WHERE table_schema = 'bigmindhadoop7613' AND table_name = 'customers';

describe customers;

select min(buyprice), max(buyprice), avg(buyprice), stddev(buyprice) from products;

-- Left Join
show tables;
describe customers;
describe orders;
select a.customernumber, customername, city, country, creditlimit, ordernumber, orderdate, b.status, requireddate from customers as a
left join orders as b on a.customernumber=b.customernumber order by b.ordernumber;
select count(*) from customers;
select count(*) from orders;
select count(distinct(customernumber)) from orders;

-- List of customers who have not placed any orders
select a.customernumber, customername, city, country, creditlimit, ordernumber, orderdate, b.status, requireddate from customers as a
left join orders as b on a.customernumber=b.customernumber where b.ordernumber is null order by a.customernumber;

-- List the customer names who placed 2 or more orders
select a.customernumber, a.customername, count(*) as numberoforders from customers as a
left join orders as b on a.customernumber=b.customernumber group by a.customernumber, a.customername having numberoforders>=2 order by numberoforders desc, a.customernumber;

-- Right Join
select a.customernumber, customername, city, country, creditlimit, ordernumber, orderdate, b.status, requireddate from orders as b 
right join customers as a on a.customernumber=b.customernumber order by b.ordernumber;

-- List the customer names who placed 2 or more orders
select a.customernumber, a.customername, count(*) as numberoforders from orders as b
right join customers as a on a.customernumber=b.customernumber group by a.customernumber, a.customername having numberoforders>=2 order by numberoforders desc, a.customernumber;

-- Inner Join
select a.customernumber, customername, city, country, creditlimit, ordernumber, orderdate, b.status, requireddate from customers as a
inner join orders as b on a.customernumber=b.customernumber order by a.customernumber;
-- How many orders are placed by each customer?
select a.customernumber, a.customername, count(*) as numberoforders from orders as b
inner join customers as a on a.customernumber=b.customernumber group by a.customernumber, a.customername having numberoforders>=2 order by numberoforders desc, a.customernumber;

describe products;
describe orderdetails;
select count(*) from orderdetails;
select count(*) from products;
select count(distinct(productcode)) from products;
select count(distinct(productcode)) from orderdetails;
select a.productcode, productname, b.ordernumber, b.quantityordered from products as a
left join orderdetails b on a.productcode=b.productcode order by b.quantityordered;

-- Subquery
-- Most expensive product
describe products;
select max(buyprice) from products;
select productcode, productname, buyprice from products where buyprice=(select max(buyprice) from products);
-- List of products whose buy price is above the average buyprice
select avg(buyprice) from products;
select productcode, productname, buyprice from products where buyprice>(select avg(buyprice) from products);
-- Number of the products whose buy price is above the average buyprice
select count(*) countofaboveavg from products where buyprice>(select avg(buyprice) from products);
-- Least expensive product
select min(buyprice) from products;
select productcode, productname, buyprice from products where buyprice=(select min(buyprice) from products);
select productline, count(*) as countofproducts, min(buyprice) as minbuyprice, avg(buyprice) avgbuyprice, max(buyprice) as maxbuyprice from products group by productline;
select productline, max(buyprice) as maxbuyprice from products group by productline order by maxbuyprice desc;
select productcode, productname, p.productline, maxbuyprice from products p
join (select productline, max(buyprice) as maxbuyprice from products group by productline) q
on p.productline=q.productline
order by maxbuyprice desc;

describe orderdetails;
select ordernumber, a.productcode, productname, productline, quantityordered, priceeach from orderdetails a
join products b on a.productcode=b.productcode;

select ordernumber, productcode, quantityordered, priceeach, 
(select productname from products b where b.productcode=orderdetails.productcode) as productname
from orderdetails;

select ordernumber, productcode, quantityordered, priceeach, 
(select productname from products b where b.productcode=orderdetails.productcode) as productname,
(select productline from products b where b.productcode=orderdetails.productcode) as productline
from orderdetails;

-- CASE WHEN and NULL Functions
select customernumber, customername, city, state, country from customers order by state;
select customernumber, customername, city, IFNULL(state,'Not Available') as state, country from customers order by state;

desc customers;
select customernumber, customername, creditlimit from customers order by creditlimit;
select max(creditlimit), min(creditlimit) from customers;

select customernumber, customername, creditlimit,
case
    when creditlimit=0 then 'new'
    when creditlimit between 0 and 100000 then 'silver'
    when creditlimit between 100000 and 200000 then 'gold'
    else 'diamond'
end as customergrade
from customers
order by creditlimit desc;

-- UNION Example
-- We want the break up of customers by credit grade in each country
select country, count(*) from customers group by country order by country;

select country, count(*) as Total, creditlimit from customers group by country,creditlimit order by country,creditlimit ;

select country, count(*) as Total, 'New' as CreditGrade from customers where creditlimit=0 group by country order by country;
select country, count(*) as Total, 'Silver' as CreditGrade from customers where creditlimit between 0 and 100000 group by country order by country;
select country, count(*) as Total, 'Gold' as CreditGrade from customers where creditlimit between 100000 and 200000 group by country order by country;
select country, count(*) as Total, 'Diamond' as CreditGrade from customers where creditlimit between 200000 and 300000 group by country order by country;

select * from
(
select country, count(*) as Total, 'New' as CreditGrade from customers where creditlimit=0 group by country
union all
select country, count(*) as Total, 'Silver' as CreditGrade from customers where creditlimit between 0 and 100000 group by country
union all
select country, count(*) as Total, 'Gold' as CreditGrade from customers where creditlimit between 100000 and 200000 group by country
union all
select country, count(*) as Total, 'Diamond' as CreditGrade from customers where creditlimit between 200000 and 300000 group by country
) as q
order by q.country, q.creditgrade;

select CreditGrade,count(*) as CountryTotal from
(
select country, count(*) as Total, 'New' as CreditGrade from customers where creditlimit=0 group by country
union all
select country, count(*) as Total, 'Silver' as CreditGrade from customers where creditlimit between 0 and 100000 group by country
union all
select country, count(*) as Total, 'Gold' as CreditGrade from customers where creditlimit between 100000 and 200000 group by country
union all
select country, count(*) as Total, 'Diamond' as CreditGrade from customers where creditlimit between 200000 and 300000 group by country
) as q
group by q.creditgrade
order by CountryTotal ;
