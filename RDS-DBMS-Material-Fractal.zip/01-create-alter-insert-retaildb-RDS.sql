CREATE DATABASE IF NOT EXISTS retaildb;

show databases;

use <your db name here>;

CREATE TABLE customers (
  customer_id int NOT NULL AUTO_INCREMENT,
  customer_fname varchar(45) NOT NULL,
  customer_lname varchar(45) NOT NULL,
  customer_email varchar(45) NOT NULL,
  customer_password varchar(45) NOT NULL,
  customer_street varchar(255) NOT NULL,
  customer_city varchar(45) NOT NULL,
  customer_state varchar(45) NOT NULL,
  customer_zipcode varchar(45) NOT NULL,
  PRIMARY KEY (customer_id)
);

show tables;

INSERT INTO `customers` VALUES 
(1,'Richard','Hernandez','XXXXXXXXX','XXXXXXXXX','6303 Heather Plaza','Brownsville','TX','78521'),
(2,'Mary','Barrett','XXXXXXXXX','XXXXXXXXX','9526 Noble Embers Ridge','Littleton','CO','80126'),
(3,'Ann','Smith','XXXXXXXXX','XXXXXXXXX','3422 Blue Pioneer Bend','Caguas','PR','00725'),
(4,'Mary','Jones','XXXXXXXXX','XXXXXXXXX','8324 Little Common','San Marcos','CA','92069'),
(5,'Robert','Hudson','XXXXXXXXX','XXXXXXXXX','10 Crystal River Mall ','Caguas','PR','00725');

select * from customers;
select count(*) from customers;

-- ALTER TABLE customers
-- MODIFY customer_email varchar(45) NULL,
-- MODIFY customer_password varchar(45) NULL;

create table customers_b
as
select customer_id, customer_fname, customer_lname, customer_street, customer_city, customer_state, customer_zipcode from customers;

show tables;

describe customers_b;

select * from customers_b;
select count(*) from customers_b;

INSERT INTO `customers_b`
SET customer_id=6,customer_fname='Mary',customer_lname='Smith',customer_street='3151 Sleepy Quail Promenade',customer_city='Passaic',customer_state='NJ',customer_zipcode='07055';

select * from customers_b;
select count(*) from customers_b;

INSERT INTO `customers_b`
SET customer_id=7,customer_fname='Melissa',customer_lname='Wilcox',customer_street='9453 High Concession',customer_city='Caguas',customer_state='PR',customer_zipcode='00725';

select * from customers_b;
select count(*) from customers_b;

CREATE TABLE customers_c (
  customer_id int NOT NULL AUTO_INCREMENT,
  customer_fname varchar(45) NOT NULL,
  customer_lname varchar(45) NOT NULL,
  customer_email varchar(45),
  customer_password varchar(45),
  customer_street varchar(255) NOT NULL,
  customer_city varchar(45) NOT NULL,
  customer_state varchar(45) NOT NULL,
  customer_zipcode varchar(45) NOT NULL,
  PRIMARY KEY (customer_id)
);

show tables;
describe customers_c;

select * from customers_c;
select count(*) from customers_c;

insert into customers_c (customer_id, customer_fname, customer_lname, customer_street, customer_city, customer_state, customer_zipcode)
select customer_id, customer_fname, customer_lname, customer_street, customer_city, customer_state, customer_zipcode from customers;

select * from customers_c;
select count(*) from customers_c;

-- Day - 2

describe customers_c;
CREATE TABLE customers_d LIKE customers_c;
describe customers_d;

select * from customers_d;
select count(*) from customers_d;

insert into customers_d (customer_id, customer_fname, customer_lname, customer_street, customer_city, customer_state, customer_zipcode)
select customer_id, customer_fname, customer_lname, customer_street, customer_city, customer_state, customer_zipcode from customers;

select * from customers_d;
select count(*) from customers_d;

describe customers_b;
alter table customers_b
add
(  customer_email varchar(45),
  customer_password varchar(45)
);
describe customers_b;

alter table customers_b
drop customer_password;
-- Multiple columns to be given with individual drop clauses
describe customers_b;

alter table customers_b
modify column customer_email varchar(60);
describe customers_b;

alter table customers_b
change column customer_email customer_email_Id varchar(45);
describe customers_b;

alter table customers_b
add
( customer_fullname varchar(90)
);
describe customers_b;

SET SQL_SAFE_UPDATES = 0;

update customers_b
set customer_fullname=concat(customer_fname, ' ', customer_lname);

select customer_id, customer_fname, customer_lname, customer_fullname from customers_b;

UPDATE customers_b as a
SET customer_email_id = (SELECT customer_email FROM customers as b where a.customer_id=b.customer_id);

select customer_id, customer_fname, customer_lname, customer_email_Id from customers_b;

DELETE FROM customers_b WHERE customer_id=6;

-- SELECT Queries

=======================================================================================================================================

