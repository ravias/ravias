-- By default autocommit is enabled in MySQL.
-- To turn it off, we will set the value of autocommit to 0.

SET autocommit = 0;

-- Let us now create a table and insert some data
-- Then quit mysql client without executing COMMIT command

CREATE TABLE customers (
  customer_id int NOT NULL AUTO_INCREMENT,
  customer_fname varchar(45) NOT NULL,
  customer_lname varchar(45) NOT NULL,
  customer_email varchar(45) NOT NULL,
  customer_password varchar(45) NOT NULL,
  customer_street varchar(255) NOT NULL,
  customer_city varchar(45) NOT NULL,
  customer_state varchar(45) NOT NULL,
  customer_zipcode varchar(45) NOT NULL,
  PRIMARY KEY (customer_id)
);

show tables;

INSERT INTO `customers` VALUES 
(1,'Richard','Hernandez','XXXXXXXXX','XXXXXXXXX','6303 Heather Plaza','Brownsville','TX','78521'),
(2,'Mary','Barrett','XXXXXXXXX','XXXXXXXXX','9526 Noble Embers Ridge','Littleton','CO','80126'),
(3,'Ann','Smith','XXXXXXXXX','XXXXXXXXX','3422 Blue Pioneer Bend','Caguas','PR','00725'),
(4,'Mary','Jones','XXXXXXXXX','XXXXXXXXX','8324 Little Common','San Marcos','CA','92069'),
(5,'Robert','Hudson','XXXXXXXXX','XXXXXXXXX','10 Crystal River Mall ','Caguas','PR','00725');

select * from customers;
select count(*) from customers;

quit;

-- Now run mysql again and use the database
-- Check the table

show tables;

select * from customers;
select count(*) from customers;

-- We will find that the table that was created is available
-- But the data/records inserted are not there any more
-- This is because we did not run commit command

-- Now let us inset the data/records into the table again
-- As we have not set autocommit to 0 these insertions are autocommitted

INSERT INTO `customers` VALUES 
(1,'Richard','Hernandez','XXXXXXXXX','XXXXXXXXX','6303 Heather Plaza','Brownsville','TX','78521'),
(2,'Mary','Barrett','XXXXXXXXX','XXXXXXXXX','9526 Noble Embers Ridge','Littleton','CO','80126'),
(3,'Ann','Smith','XXXXXXXXX','XXXXXXXXX','3422 Blue Pioneer Bend','Caguas','PR','00725'),
(4,'Mary','Jones','XXXXXXXXX','XXXXXXXXX','8324 Little Common','San Marcos','CA','92069'),
(5,'Robert','Hudson','XXXXXXXXX','XXXXXXXXX','10 Crystal River Mall ','Caguas','PR','00725');

select * from customers;
select count(*) from customers;

-- START TRANSACTION command is used to start the transaction.

START TRANSACTION;

-- SAVEPOINT command in SQL is used to save the different steps/operatioons of the same transaction using different names.
-- Let us consider insertion as one step/operation of our transaction.
-- We will save this part using a savepoint named Insertion.
SAVEPOINT Insertion;

-- Now let us update one of the records as the next step of our transaction.

UPDATE customers 
SET customer_zipcode = '78520' WHERE customer_id = 1; 

select * from customers;
select count(*) from customers;

-- Let us save this step using a savepoint named Updation.
SAVEPOINT Updation;  

select * from customers;
select count(*) from customers;

-- Now let us say for some reason we do not want the update to be done.
-- We can roll back our transaction to the savepoint, which was created prior to the execution of the UPDATE command. 

ROLLBACK TO Insertion;  

select * from customers;
select count(*) from customers;
